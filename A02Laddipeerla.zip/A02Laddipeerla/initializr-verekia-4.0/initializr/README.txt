# 44-563 A01 Introduction to JavaScript

A complete web content with a total of 3 pages introducing me along with a page for my choice which I have decided to make a world timer in my later assignment.
I have built a calculator as one of the pages which calculates the costs total construction cost if the user inputs the different values


# Uses

- HTML, a markup language for web apps
- CSS, a style sheet language for styling markup languages like html
- BootStrap, a framework for responsive web design
- QUnit, a unit testing framework for JavaScript

# References

- http://www.w3schools.com/html/default.asp
- https://www.google.com/search?q=world+clock&biw=1517&bih=735&source=lnms&tbm=isch&sa=X&ved=0ahUKEwjl54v9gOTRAhVM4YMKHUGBBI8Q_AUICCgD#imgrc=eNwFWKTdV46P1M%3A
- https://validator.w3.org/